package net.redborder.darklistupdate.utils.http;

/**
 * Created by andresgomez on 18/2/15.
 */
public class HttpURLs {
    public static final String URL = "https://reputation.alienvault.com/";
    public static final String CURRENT_REVISION = "reputation.rev";
    public static final String ALL_DATA = "reputation.data";
    public static final String ONE_REVISION = "revisions/reputation.data_";
}
